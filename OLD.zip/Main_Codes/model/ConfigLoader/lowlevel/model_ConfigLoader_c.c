/*==========================================================
BASE C TEMPLATE
==========================================================*/
#include "model_ConfigLoader_c.h"

int basic_function() {
    return 1;
}
