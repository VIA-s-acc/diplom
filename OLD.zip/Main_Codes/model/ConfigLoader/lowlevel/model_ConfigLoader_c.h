/*==========================================================
BASE HEADER TEMPLATE
==========================================================*/
#ifndef CONFIGLOADER_H
#define CONFIGLOADER_H


int basic_function();

#endif // CONFIGLOADER_H
