var annotated_dup =
[
    [ "ConfigLoader", "dc/d07/namespace_config_loader.html", [
      [ "ConfigLoader", "db/dd3/class_config_loader_1_1_config_loader.html", "db/dd3/class_config_loader_1_1_config_loader" ]
    ] ],
    [ "Field", "d0/dfa/namespace_field.html", [
      [ "Field", "d5/db6/class_field_1_1_field.html", "d5/db6/class_field_1_1_field" ]
    ] ],
    [ "Optimizer", "d2/d47/namespace_optimizer.html", [
      [ "GradientOptimizer", "d1/db9/class_optimizer_1_1_gradient_optimizer.html", "d1/db9/class_optimizer_1_1_gradient_optimizer" ]
    ] ]
];