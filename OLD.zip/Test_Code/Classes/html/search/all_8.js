var searchData=
[
  ['of_20contents_0',['Table of Contents',['../index.html#toc',1,'']]],
  ['optimizer_1',['Optimizer',['../d2/d47/namespace_optimizer.html',1,'']]],
  ['optimizer_2epy_2',['Optimizer.py',['../d7/de0/_optimizer_8py.html',1,'']]]
];
