var searchData=
[
  ['пример_0',['Пример',['../d2/d47/namespace_optimizer.html#example',1,'']]],
  ['проекта_1',['Документация проекта',['../index.html',1,'']]]
];
