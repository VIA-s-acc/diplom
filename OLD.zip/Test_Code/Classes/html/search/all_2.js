var searchData=
[
  ['base_0',['base',['../da/d82/namespace_funcs.html#a91667077074ca6ae6e541474cd832ffa',1,'Funcs']]]
];
