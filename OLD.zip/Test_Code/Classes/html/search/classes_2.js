var searchData=
[
  ['gradientoptimizer_0',['GradientOptimizer',['../d1/db9/class_optimizer_1_1_gradient_optimizer.html',1,'Optimizer']]]
];
