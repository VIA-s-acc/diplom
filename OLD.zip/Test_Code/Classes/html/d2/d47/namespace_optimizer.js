var namespace_optimizer =
[
    [ "GradientOptimizer", "d1/db9/class_optimizer_1_1_gradient_optimizer.html", "d1/db9/class_optimizer_1_1_gradient_optimizer" ]
];