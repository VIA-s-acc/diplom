var _funcs_8py =
[
    [ "Funcs.base", "da/d82/namespace_funcs.html#a91667077074ca6ae6e541474cd832ffa", null ],
    [ "Funcs.dGkdv", "da/d82/namespace_funcs.html#a80b93b6b7e1123f89ffad64a72acbc06", null ],
    [ "Funcs.dGkdw", "da/d82/namespace_funcs.html#ae5c9974d6e485df93dd2249ed6cd801a", null ],
    [ "Funcs.exp_step", "da/d82/namespace_funcs.html#a9b2b0e99d261b02ee529c42d8ab7814f", null ],
    [ "Funcs.Gk", "da/d82/namespace_funcs.html#a4386136e854f2da3c3f181e880884fb0", null ],
    [ "Funcs.plot_Gk", "da/d82/namespace_funcs.html#aed47335ae230f8da8b0b9b068c56d29d", null ],
    [ "Funcs.poly_step", "da/d82/namespace_funcs.html#a12f0b5c7405890358431b8a83a82819f", null ]
];