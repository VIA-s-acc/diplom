var class_optimizer_1_1_gradient_optimizer =
[
    [ "__init__", "d1/db9/class_optimizer_1_1_gradient_optimizer.html#aebcc184bc32a45e1d88f7171cd8ac62f", null ],
    [ "Gradien_max_Field", "d1/db9/class_optimizer_1_1_gradient_optimizer.html#a4212b4d9598608078ee64da50f2b90ab", null ],
    [ "Gradient_Max_step", "d1/db9/class_optimizer_1_1_gradient_optimizer.html#a9db35f33facd7619f29a4a76b7e091af", null ]
];