var files_dup =
[
    [ "ConfigLoader.py", "d7/d28/_config_loader_8py.html", "d7/d28/_config_loader_8py" ],
    [ "Field.py", "d4/def/_field_8py.html", "d4/def/_field_8py" ],
    [ "Funcs.py", "d4/d7f/_funcs_8py.html", "d4/d7f/_funcs_8py" ],
    [ "Optimizer.py", "d7/de0/_optimizer_8py.html", "d7/de0/_optimizer_8py" ]
];