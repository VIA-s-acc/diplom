var _optimizer_8py =
[
    [ "GradientOptimizer", "d1/db9/class_optimizer_1_1_gradient_optimizer.html", "d1/db9/class_optimizer_1_1_gradient_optimizer" ]
];